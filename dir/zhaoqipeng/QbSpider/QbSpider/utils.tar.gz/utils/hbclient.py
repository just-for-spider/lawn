# -*- coding: utf-8 -*-
import os
import sys
import traceback

sys.path.append(os.path.abspath("../"))
import time
from thrift.transport import TSocket
from thrift.protocol import TBinaryProtocol
from QbSpider.hbases import Hbase
from QbSpider.hbases.ttypes import *
import json

class HbUnicom(object):
    """
    172.28.40.43:9090 thrift1
    """

    #def __init__(self, host='172.28.40.23', port=9090, tabName='login_key_page', mapName='login_user_keys'):
    def __init__(self, host='172.28.40.45', port=9090, tabName='login_key_page', mapName='login_user_keys'):
    #def __init__(self, host='172.28.40.43', port=9090, tabName='login_key_page', mapName='login_user_keys'):
        self.tabName = tabName
        self.mapName = mapName
        self.transport = TTransport.TBufferedTransport(TSocket.TSocket(host, port), rbuf_size=512)
        self.protocol = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client = Hbase.Client(self.protocol)
        # print self.client
        self.transport.open()
        #self.logger = logging.getLogger('spider')

    def __del__(self):
        self.transport.close()

    def __genkey(self, phone, url, post_data):
        if isinstance(post_data,int):
            post_data = str(post_data)
        row_key = '%s_%s' % (phone, url)
        if post_data:
            row_key += '_' + post_data
        return row_key

    def __inserttm(self, rowkey):
        mutations = [Mutation(column="c:yys_tm", value=self.__gentm())]
        self.client.mutateRow(self.mapName, rowkey, mutations, None)

    def __gentm(self):
        return str(int(time.time()))

    def insert_page(self, url, phone, html, charset, struct_json, post_data=None):
        """
        schema:
        f:url -> 网页地址
        f:cnt -> 网页
        f:typ -> 网页编码
        p:json -> 结构化数据json
        """
        try:
            row_key = self.__genkey(phone, url, post_data)
            mutations = [Mutation(column="f:url", value=url),
                         Mutation(column="f:cnt", value=html),
                         Mutation(column="f:typ", value=charset),
                         Mutation(column="f:tm", value=self.__gentm()),
                         Mutation(column="p:json", value=json.dumps(struct_json))]
            self.client.mutateRow(self.tabName, row_key, mutations, None)
        except Exception, e:
            print traceback.format_exc()
            print e.message
            print 'rowkey:', row_key
            print 'data:', struct_json

    def insert_person_info(self, phone, jobid, url, post_data=None):
        """
        用户信息:个人信息
        """
        row_key = 'YYS_LT_%s_%s' % (phone, jobid)
        # 这里要设置为全局变量
        data_key = self.__genkey(phone, url, post_data)
        data_key += '\t'
        try:
            append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_pi'], values=[data_key])
            self.client.append(append)
            self.__inserttm(row_key)
        except Exception, e:
            print traceback.format_exc()
            print e.message
            print 'rowkey:', row_key
            print 'data:', data_key

    def insert_bill_statis(self, phone, jobid, url, post_data=None):
        """
        账单查询:六个月的话费统计
        """
        row_key = 'YYS_LT_%s_%s' % (phone, jobid)
        # 这里要设置为全局变量
        data_key = self.__genkey(phone, url, post_data)
        data_key += '\t'

        try:
            append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_bs'], values=[data_key])
            self.client.append(append)
            self.__inserttm(row_key)
        except Exception, e:
            print traceback.format_exc()
            print e.message
            print 'rowkey:', row_key
            print 'data:', data_key

    def insert_bill_detail(self, phone, jobid, url, post_data=None):
        """
        详单查询:
        """
        row_key = 'YYS_LT_%s_%s' % (phone, jobid)
        # 这里要设置为全局变量
        data_key = self.__genkey(phone, url, post_data)
        data_key += '\t'

        try:
            append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_bd'], values=[data_key])
            self.client.append(append)
            self.__inserttm(row_key)
        except Exception, e:
            print traceback.format_exc()
            print e
            print e.message
            print 'rowkey:', row_key
            print 'data:', data_key

    def insert_account_info(self, phone, jobid, url, post_data=None):
        """
        账户信息：
        """
        row_key = 'YYS_LT_%s_%s' % (phone, jobid)
        # 这里要设置为全局变量
        data_key = self.__genkey(phone, url, post_data)
        data_key += '\t'

        try:
            append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_ai'], values=[data_key])
            self.client.append(append)
            self.__inserttm(row_key)
        except Exception, e:
            print traceback.format_exc()
            print e
            print e.message
            print 'rowkey:', row_key
            print 'data:', data_key

    def insert_charge_detail(self, phone, jobid, url, post_data=None):
        """
        费用明细:
        """
        row_key = 'YYS_LT_%s_%s' % (phone, jobid)
        # 这里要设置为全局变量
        data_key = self.__genkey(phone, url, post_data)
        data_key += '\t'

        try:
            append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_cd'], values=[data_key])
            self.client.append(append)
            self.__inserttm(row_key)
        except Exception, e:
            print traceback.format_exc()
            print e
            print e.message
            print 'rowkey:', row_key
            print 'data:', data_key

    def insert_remain_score(self, phone, jobid, url, post_data=None):
        """
        积分余额
        """
        row_key = 'YYS_LT_%s_%s' % (phone, jobid)
        # 这里要设置为全局变量
        data_key = self.__genkey(phone, url, post_data)
        data_key += '\t'

        try:
            append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_rs'], values=[data_key])
            self.client.append(append)
            self.__inserttm(row_key)
        except Exception, e:
            print traceback.format_exc()
            print e
            print e.message
            print 'rowkey:', row_key
            print 'data:', data_key

    def insert_commu_amount(self, phone, jobid, url, post_data=None):
        """
        通信量
        """
        row_key = 'YYS_LT_%s_%s' % (phone, jobid)
        # 这里要设置为全局变量
        data_key = self.__genkey(phone, url, post_data)
        data_key += '\t'

        try:
            append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_ca'], values=[data_key])
            self.client.append(append)
            self.__inserttm(row_key)
        except Exception, e:
            print traceback.format_exc()
            print e
            print e.message
            print 'rowkey:', row_key
            print 'data:', data_key

    def insert_account_detail(self, phone, jobid, url, post_data=None):
        """
        账户明细
        """
        row_key = 'YYS_LT_%s_%s' % (phone, jobid)
        # 这里要设置为全局变量
        data_key = self.__genkey(phone, url, post_data)
        data_key += '\t'

        try:
            append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_ad'], values=[data_key])
            self.client.append(append)
            self.__inserttm(row_key)
        except Exception, e:
            print traceback.format_exc()
            print e
            print e.message
            print 'rowkey:', row_key
            print 'data:', data_key

    def insert_record_login(self, phone, jobid, url, post_data=None):
        """
        用户登录信息
        """
        row_key = 'YYS_LT_%s_%s' % (phone, jobid)
        # 这里要设置为全局变量
        data_key = self.__genkey(phone, url, post_data)
        #data_key += '\ttest'
        data_key += '\t'
        #append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_ld'], values=[data_key])
        #self.client.append(append)
        try:
            append = TAppend(table=self.mapName, row=row_key, columns=['c:yys_ld'], values=[data_key])
            self.client.append(append)
            self.__inserttm(row_key)
        except Exception, e:
            print traceback.format_exc()
            print e
            print e.message
            print 'rowkey:', row_key
            print 'data:', data_key

