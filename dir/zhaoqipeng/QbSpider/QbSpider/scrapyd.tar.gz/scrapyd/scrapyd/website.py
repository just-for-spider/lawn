from datetime import datetime

import socket

from twisted.web import resource, static
from twisted.application.service import IServiceCollection

from scrapy.utils.misc import load_object

from .interfaces import IPoller, IEggStorage, ISpiderScheduler

from urlparse import urlparse

import psutil
import time

class Root(resource.Resource):

    def __init__(self, config, app):
        resource.Resource.__init__(self)
        self.debug = config.getboolean('debug', False)
        self.runner = config.get('runner')
        logsdir = config.get('logs_dir')
        itemsdir = config.get('items_dir')
        local_items = itemsdir and (urlparse(itemsdir).scheme.lower() in ['', 'file'])
        self.app = app
        self.nodename = config.get('node_name', socket.gethostname())
        self.putChild('', Home(self, local_items))
        if logsdir:
            self.putChild('logs', static.File(logsdir, 'text/plain'))
        if local_items:
            self.putChild('items', static.File(itemsdir, 'text/plain'))
        self.putChild('jobs', Jobs(self, local_items))
        services = config.items('services', ())
        for servName, servClsName in services:
          servCls = load_object(servClsName)
          self.putChild(servName, servCls(self))
        self.update_projects()

    def update_projects(self):
        self.poller.update_projects()
        self.scheduler.update_projects()

    @property
    def launcher(self):
        app = IServiceCollection(self.app, self.app)
        return app.getServiceNamed('launcher')

    @property
    def scheduler(self):
        return self.app.getComponent(ISpiderScheduler)

    @property
    def eggstorage(self):
        return self.app.getComponent(IEggStorage)

    @property
    def poller(self):
        return self.app.getComponent(IPoller)


class Home(resource.Resource):

    def __init__(self, root, local_items):
        resource.Resource.__init__(self)
        self.root = root
        self.local_items = local_items

    def render_GET(self, txrequest):
        vars = {
            'projects': ', '.join(self.root.scheduler.list_projects()),
        }
        s = """
<html>
<head><title>Scrapyd</title></head>
<body>
<h1>Scrapyd</h1>
<p>Available projects: <b>%(projects)s</b></p>
<ul>
<li><a href="/jobs">Jobs</a></li>
""" % vars
        if self.local_items:
            s += '<li><a href="/items/">Items</a></li>'
        s += """
<li><a href="/logs/">Logs</a></li>
<li><a href="http://scrapyd.readthedocs.org/en/latest/">Documentation</a></li>
</ul>

<h2>How to schedule a spider?</h2>

<p>To schedule a spider you need to use the API (this web UI is only for
monitoring)</p>

<p>Example using <a href="http://curl.haxx.se/">curl</a>:</p>
<p><code>curl http://localhost:6800/schedule.json -d project=default -d spider=somespider</code></p>

<p>For more information about the API, see the <a href="http://scrapyd.readthedocs.org/en/latest/">Scrapyd documentation</a></p>
</body>
</html>
""" % vars
        return s

class Jobs(resource.Resource):

    def __init__(self, root, local_items):
        resource.Resource.__init__(self)
        self.root = root
        self.local_items = local_items

    def render(self, txrequest):
        cols = 17
        s = "<html><head><title>Scrapyd</title>"
        s+='''<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>'''
        s += '''<script type="text/javascript">function stopspider(project,job,signal){$.ajax({type: "POST",url: "cancel.json",data: {"project":project,"job":job,"signal":signal},success: function(){alert("Close Spider Success");}});}</script>'''
        s += "</head>"
        s += "<body>"
        s += "<h1>Jobs</h1>"
        s += "<p><a href='..'>Go back</a></p>"
        s += "<table border='1'>"
        s += "<tr><th>Project</th><th>Spider</th><th>Job</th><th>PID</th><th>Ram_Percent</th><th>Ram_Rss</th><th>Ram_Vms</th><th>Cpu_Percent</th>" \
             "<th>Cpu_Time_User</th><th>Cpu_Time_System</th><th>Num_Fds</th><th>Context_Switches</th><th>Num_Threads</th><th>Server_Time</th><th>Runtime</th><th>Log</th>"
        if self.local_items:
            s += "<th>Items</th>"
            cols = 18
        if cols == 18:
            cols = 19
        else:
            cols = 18
        s += "<th>Stop Spider</th>"
        s += "</tr>"
        s += "<tr><th colspan='%s' style='background-color: #ddd'>Pending</th></tr>" % cols
        for project, queue in self.root.poller.queues.items():
            for m in queue.list():
                s += "<tr>"
                s += "<td>%s</td>" % project
                s += "<td>%s</td>" % str(m['name'])
                s += "<td>%s</td>" % str(m['_job'])
                s += "</tr>"
        s += "<tr><th colspan='%s' style='background-color: #ddd'>Running</th></tr>" % cols
        for p in self.root.launcher.processes.values():
            s += "<tr>"
            for a in ['project', 'spider', 'job', 'pid']:
                s += "<td>%s</td>" % getattr(p, a)
            process = psutil.Process(p.pid)
            cpu_times = process.cpu_times()
            ram_usage = process.memory_info()
            switches = process.num_ctx_switches()
            ram_percent = str(process.memory_percent())
            ram_rss = str(ram_usage.rss)
            ram_vms = str(ram_usage.vms)
            cpu_percent = str(process.cpu_percent())
            cpu_time_user = str(cpu_times.user)
            cpu_time_system = str(cpu_times.system)
            num_fds = str(process.num_fds())
            context_switches = "invol:%s,vol:%s"%(str(switches.involuntary),str(switches.voluntary))
            num_threads = str(process.num_threads())
            server_time = str(time.strftime('%Y/%m/%d %H:%M:%S', time.localtime(time.time())))
            s += "<td>%s</td>"%ram_percent
            s += "<td>%s</td>" % ram_rss
            s += "<td>%s</td>" % ram_vms
            s += "<td>%s</td>" % cpu_percent
            s += "<td>%s</td>" % cpu_time_user
            s += "<td>%s</td>" % cpu_time_system
            s += "<td>%s</td>" % num_fds
            s += "<td>%s</td>" % context_switches
            s += "<td>%s</td>" % num_threads
            s += "<td>%s</td>" % server_time
            s += "<td>%s</td>" % (datetime.now() - p.start_time)
            s += "<td><a href='/logs/%s/%s/%s.log'>Log</a></td>" % (p.project, p.spider, p.job)
            # if self.local_items:
            #     s += "<td><a href='/items/%s/%s/%s.jl'>Items</a></td>" % (p.project, p.spider, p.job)
            s += "<td><a href='/items/%s/%s/%s.jl'>Items</a></td>" % (p.project, p.spider, p.job)
            s += '''<td><input id="stop" type="button" value="Stop" onclick="stopspider('%s','%s','%s')"/></td>'''%(p.project,p.job,'TERM')
            s += "</tr>"
        s += "<tr><th colspan='%s' style='background-color: #ddd'>Finished</th></tr>" % cols
        for p in self.root.launcher.finished:
            s += "<tr>"
            for a in ['project', 'spider', 'job']:
                s += "<td>%s</td>" % getattr(p, a)
            s += "<td></td>"
            s += "<td>%s</td>" % (p.end_time - p.start_time)
            s += "<td><a href='/logs/%s/%s/%s.log'>Log</a></td>" % (p.project, p.spider, p.job)
            if self.local_items:
                s += "<td><a href='/items/%s/%s/%s.jl'>Items</a></td>" % (p.project, p.spider, p.job)
            s += "</tr>"
        s += "</table>"
        s += "</body>"
        s += "</html>"
        return s
